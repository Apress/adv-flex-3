/*AllTimeTop10Scorers.java*/

package org.advancedflex.chapter06.example;

import java.util.Vector;
import java.util.Iterator;

public class AllTimeTop10Scorers implements java.io.Serializable {
    private Vector top10ScorersCollection = new Vector();

    public AllTimeTop10Scorers() {
        top10ScorersCollection.addElement (new 
            Scorer("Kareem", "Abdul-Jabbar", 38387, 1));
        top10ScorersCollection.addElement (new 
            Scorer("Wilt", "Chamberlain", 31419, 2));
        top10ScorersCollection.addElement (new 
            Scorer("Karl", "Malone", 30599, 3));
        top10ScorersCollection.addElement (new 
             Scorer("Michael", "Jordan", 29277, 4));
        top10ScorersCollection.addElement (new 
             Scorer("Moses", "Malone", 27409, 5));
        top10ScorersCollection.addElement (new 
             Scorer("Elvin", "Hayes", 27313, 6));
        top10ScorersCollection.addElement (new 
             Scorer("Oscar", "Robertson", 26710, 7));
        top10ScorersCollection.addElement (new 
             Scorer("Dominique", "Wilkins", 26669, 8));
        top10ScorersCollection.addElement (new 
             Scorer("John", "Havlicek", 26395, 9));
        top10ScorersCollection.addElement (new 
             Scorer("Alex", "English", 25613, 10));
    }

    public Iterator getTop10ScorersCollection() {
        return top10ScorersCollection.iterator();
    }
}
