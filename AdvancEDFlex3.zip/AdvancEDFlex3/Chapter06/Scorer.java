/*Scorer.java*/

package org.advancedflex.chapter06.example;

public class Scorer implements java.io.Serializable {
    private String firstName;
    private String lastName;
    private int totalScore;
    private int position;

    public Scorer(String firstName, String lastName, 
    int totalScore, int position) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.totalScore = totalScore;
        this.position = position;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
