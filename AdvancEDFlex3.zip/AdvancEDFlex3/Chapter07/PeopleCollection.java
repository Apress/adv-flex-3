package advancedflex3.ch07.remoting;

import java.io.*;
import java.net.URLDecoder;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.util.List;
import java.util.ArrayList;

public class PeopleCollection
{
    public PeopleCollection() {

    }

    public List getPersons() {

        List list = new ArrayList();

        try {
            String filePath = URLDecoder.decode(getClass().~CCC
getClassLoader().getResource~CCC
("advancedflex3/ch07/PeopleCollection.xml").~CCC
getFile(), "UTF-8");;
            DocumentBuilderFactory factory = 
DocumentBuilderFactory.newInstance();
            factory.setValidating(false);
            Document doc = 
factory.newDocumentBuilder().~CCC
parse(new File(filePath));
            NodeList personNodes = doc.getElementsByTagName("person");
            int length = personNodes.getLength();
            Person person;
            Node personNode;
            for (int i=0; i<length; i++) {
                personNode = personNodes.item(i);
                person = new Person();
                person.setId(getIntegerValue(personNode, "id"));
                person.setFirstName(getStringValue~CCC
(personNode, "firstName"));
                person.setLastName(getStringValue~CCC
(personNode, "lastName"));
                person.setCountry(getStringValue~CCC
(personNode, "country"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    private String getStringValue(Node node, String name) {
        return ((Element) node).getElementsByTagName~CCC
(name).item(0).getFirstChild().getNodeValue();
    }

    private int getIntegerValue(Node node, String name) {
        return Integer.parseInt(getStringValue(node, name) );
    }
}
