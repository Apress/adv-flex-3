var _gotoLocation = '';

function mapComplete() {
	document.getElementById('mapwidget').gotoAddress( _gotoLocation );
}

function putMapWidget( gotoLocation )
{
	_gotoLocation = gotoLocation;
	AC_FL_RunContent(
			"src", "mapwidget",
			"width", "100%",
			"height", "100%",
			"align", "middle",
			"id", "mapwidget",
			"quality", "high",
			"allowScriptAccess","always",
			"type", "application/x-shockwave-flash",
			"pluginspage", "http://www.adobe.com/go/getflashplayer"
	);
}
