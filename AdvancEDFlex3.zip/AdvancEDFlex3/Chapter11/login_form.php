<html>
<head>
<title>Login Form</title>
</head>
<body>
<form method="post" action="<?php echo $PHP_SELF;?>">
User Name:<input type="text" 
size="12" 
maxlength="36" 
name="username">:<br />
Password:<input type="text" 
size="12" 
maxlength="15" 
name="password">:<br />
Role::<br />
Administrator:<input type="radio" value="Admin" name="role">:<br />
Super User:<input type="radio" value="SuperUser" name="role">:<br />
Regular User:<input type="radio" 
value="RegularUser" 
name="role">:<br />
Please choose your preferences::<br />
Remember Password:<input type="checkbox" 
value="RememberPassword"  name="preferences[]">:<br />
Expire session only on logout:<input type="checkbox" 
value="ExpireOnLogout"  name="preferences[]">:<br />
<textarea 
rows="5" 
cols="20" 
name="quote" 
wrap="physical">
Leave a message for the administrator if required
</textarea>:<br />
Select your department:<br />
<select name="department">
<option value="InformationSystems">Information Systems</option>
<option value="Sales">Sales</option>
<option value="Operations">Operations</option></select>:<br />
</body>
</html>
